# Thông tin và đồng thuận

Ứng dụng này hỗ trợ sàng lọc tự đánh giá. Không thu thập danh tính.
Bằng cách tiếp tục, bạn xác nhận đã trên 16 tuổi và đồng ý sử dụng.